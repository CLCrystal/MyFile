package com.yijian.bbs.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class EncodingFilter implements Filter {
	String encoding = null;
    //销毁时调用
	public void destroy() {

	}
    //执行
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain fc) throws IOException, ServletException {
		System.out.println("......");

		if (!encoding.equals(null)) {
			System.out.println(encoding);

			req.setCharacterEncoding(encoding);
			resp.setContentType("text/html;charset=" + encoding);

		}

		fc.doFilter(req, resp);

	}
    //初始化
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("字符过滤器");

		encoding = arg0.getInitParameter("encoding");

	}

}
