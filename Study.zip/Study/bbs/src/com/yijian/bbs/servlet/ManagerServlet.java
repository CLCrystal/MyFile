package com.yijian.bbs.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ManagerServlet extends  HttpServlet {

	/** @Fields serialVersionUID : TODO(序列化保证对象唯一)
	*/
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//获取请求路径
		String action = request.getServletPath();
		
		//登录请求
		if("login.do".equals(action)){
			doLogin(request,response);
		}
		
		
	}
   //处理登录的方法
	public void doLogin(HttpServletRequest request,
			HttpServletResponse response) {
		
		
	}
	

}
