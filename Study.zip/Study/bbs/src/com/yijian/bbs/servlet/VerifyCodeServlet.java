package com.yijian.bbs.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class VerifyCodeServlet extends HttpServlet {

	/** @Fields serialVersionUID : TODO(序列化保证对象唯一)
	*/
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String data = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		Random ran = new Random();

		// 创建一个图片
		BufferedImage img = new BufferedImage(100, 40, BufferedImage.TYPE_INT_RGB);

		// 得到图片上的一个画笔
		Graphics g = img.getGraphics();

		// 设置画笔的颜色，用来做边框颜色
		g.setColor(new Color(225, 225, 225));
		// 用画笔来填充一个矩形，矩形的左上角坐标，宽，高
		g.fillRect(0, 0, 100, 40);

		// 画底色矩形
		g.setColor(Color.WHITE);
		g.fillRect(1, 1, 100 - 2, 40 - 2);

		// 设置字体：宋体、不带格式的、字号
		g.setFont(new Font("宋体", Font.ITALIC + Font.BOLD, 20));

		StringBuffer s = new StringBuffer();
		for (int i = 0; i < 4; i++) {
			// 生成一个随机颜色 并设置给画笔
			g.setColor(new Color(ran.nextInt(255), ran.nextInt(255), ran.nextInt(255)));
			// 随机取一个字
			int index = ran.nextInt(data.length());
			// 设置验证码
			s.append(data.charAt(index));
			g.drawString(data.substring(index, index + 1), 100 / 6 * (i + 1), 25);
		}

		// 干扰素
		for (int i = 0; i < 1; i++) {
			g.setColor(new Color(ran.nextInt(255), ran.nextInt(255), ran.nextInt(255)));
			g.drawLine(ran.nextInt(100), ran.nextInt(40), ran.nextInt(100), ran.nextInt(40));
			g.drawOval(ran.nextInt(100), ran.nextInt(40), 2, 2);
		}

		// 将验证码写入session
		HttpSession session = req.getSession();
		session.setAttribute("code", s.toString());

		// 将图片写入页面
		ImageIO.write(img, "jpg", resp.getOutputStream());

	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
