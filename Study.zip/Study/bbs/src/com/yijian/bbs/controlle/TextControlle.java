package com.yijian.bbs.controlle;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yijian.bbs.model.Text;
import com.yijian.bbs.service.TextService;
import com.yijian.bbs.service.TextServiceImpl;

public class TextControlle extends HttpServlet {

	/**
	 * @Fields serialVersionUID : TODO(序列化保证对象唯一)
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;utf-8");
		String name = request.getParameter("note");
		System.out.println(name + "111111111111111111111");
		// 分页准备
		// 1.每页多少条数据
		int pageSize = 2;
		// 2.一共多少条数据？
		TextService t = new TextServiceImpl();
		int allCount = t.getCountText();
		// 3.总页数
		int allPage = (allCount - 1 + pageSize) / pageSize;
		// 4.当前第几页
		int page = 1;

		// 设计前端用参数的形式传递一个page
		String pageStr = request.getParameter("page");
		// 判断不能为空
		if (pageStr != null && !pageStr.equals("")) {
			page = Integer.parseInt(pageStr);

		}
		// 避免基本错误常识发生
		if (page > allPage) {
			page = allPage;
		}
		if (page < 1) {
			page = 1;
		}

		// 分页查
		List<Text> list = t.queryAllTextpage(page, pageSize);

		// 往前端填充数据做准备
		request.getSession().setAttribute("page", page);
		request.getSession().setAttribute("allPage", allPage);
		request.getSession().setAttribute("list", list);

		// 跳转到index.jsp
		response.sendRedirect("index.jsp");
		return;
	}

}
