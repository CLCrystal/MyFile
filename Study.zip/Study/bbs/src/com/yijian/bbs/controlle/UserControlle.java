package com.yijian.bbs.controlle;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yijian.bbs.model.User;
import com.yijian.bbs.service.UserService;
import com.yijian.bbs.service.UserServiceImpl;

public class UserControlle extends HttpServlet {

	/**
	 * @Fields serialVersionUID : TODO(用一句话描述这个变量表示什么)
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 用户输入的内容
		int userId = Integer.parseInt(request.getParameter("userId"));
		String password = request.getParameter("password");
		String code = request.getParameter("code");
		System.out.println(userId + "========" + password + "=========" + code
				+ "========");

		// 得到后台session容器中的code
		String sessionCode = (String) request.getSession().getAttribute("code");

		// 验证码验证
		if (code == null || code.equals("")
				|| !code.equalsIgnoreCase(sessionCode)) {
			// 跳转一个错误页面
			request.setAttribute("msg", "验证码错误！");
			request.getRequestDispatcher("err.jsp").forward(request, response);
			return;
		}

		// 用户属性赋值给对象
		User u = new User();
		u.setUserId(userId);
		u.setPassword(password);
		// 调用service层
		UserService userser = new UserServiceImpl();
		User existuser = userser.login(u);

		// 验证用户不正确
		if (existuser == null) {
			request.setAttribute("msg", "用户名或者密码错误！");
			request.getRequestDispatcher("err.jsp").forward(request, response);
			return;
		} else {
			// 此处有用户的所有信息 user
			request.getSession().setAttribute("user", existuser);
			// 跳转登陆index.jsp
			response.sendRedirect("index.jsp");

		}

	}

}
