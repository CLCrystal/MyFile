package com.yijian.bbs.dao.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yijian.bbs.jdbc.DBUtils;
import com.yijian.bbs.model.User;

public class UserDAOImpl implements UserDAO {
	//三大对象
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	// 查询用户，用来登陆。
	public User getUserByLogin(User user) {
		conn = DBUtils.getConnection();
		String sql = "select userId,userName,password from user where userId=? and password=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, user.getUserId());
			pstmt.setString(2, user.getPassword());
			System.out.println(pstmt);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				User u = new User();
				u.setUserId(rs.getInt("userId"));
				u.setUserName(rs.getString("userName"));
				u.setPassword(rs.getString("password"));
				return u;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
