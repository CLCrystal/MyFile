package com.yijian.bbs.dao.text;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.yijian.bbs.jdbc.DBUtils;
import com.yijian.bbs.model.Text;
//帖子持久层对象
public class TextDAOImpl implements TextDAO {
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	// 查询每页多少条？
	public List<Text> queryAllTextpage(int page, int pageSize) {
		List<Text> list = new ArrayList<Text>();
		conn = DBUtils.getConnection();
		String sql = "select textId,textContent,textName,type,createName,createDate from text limit ?,?";
		try {
			pstmt = conn.prepareStatement(sql);

			/*
			 * 如果16条数据 ---countAll当前第三页-------page每页大小-------pageSize --3条
			 * 一共多少页------countAll/pageSize ??????? 7----9----数据库从那一条到哪一条？
			 * 6----8----limit 0,3
			 */
			pstmt.setInt(1, (page - 1) * pageSize);
			pstmt.setInt(2, pageSize);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Text t = new Text();
				t.setTextId(rs.getInt("textId"));
				t.setTextContent(rs.getString("textContent"));
				t.setTextName(rs.getString("textName"));
				t.setType(rs.getInt("type"));
				t.setCreateName(rs.getString("createName"));
				t.setCreateDate(rs.getString("createDate"));
				list.add(t);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(conn, pstmt, rs);
		}

		return list;
	}

	// 一共多少条？
	public int getCountText() {
		int a = 0;
		conn = DBUtils.getConnection();
		String sql = "select count(textId) from text";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				a = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(conn, pstmt, rs);
		}

		return a;
	}

	// 分页查询 所有栏目所有信息？
	public List<Text> queryAllTextpageYuLe(int page, int pageSize, int Id) {
		List<Text> list = new ArrayList<Text>();
		conn = DBUtils.getConnection();
		String sql = "select textId,textContent,textName,type, createName,createDate from text where type=?  limit ?,?";
		try {

			pstmt = conn.prepareStatement(sql);

			/*
			 * 如果16条数据 ---countAll当前第三页-------page每页大小-------pageSize --3条
			 * 一共多少页------countAll/pageSize ??????? 7----9----数据库从那一条到哪一条？
			 * 6----8----limit 0,3
			 */
			pstmt.setInt(1, Id);
			pstmt.setInt(2, (page - 1) * pageSize);
			pstmt.setInt(3, pageSize);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Text t = new Text();
				t.setTextId(rs.getInt("textId"));
				t.setTextContent(rs.getString("textContent"));
				t.setTextName(rs.getString("textName"));
				t.setType(rs.getInt("type"));
				t.setCreateName(rs.getString("createName"));
				t.setCreateDate(rs.getString("createDate"));
				list.add(t);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(conn, pstmt, rs);
		}

		return list;
	}

	// 查询一共多少条信息？
	public int getCountTextYuLe(int Id) {
		int a = 0;
		conn = DBUtils.getConnection();
		String sql = "select count(textId) from text where type=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				a = rs.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(conn, pstmt, rs);
		}

		return a;
	}

}
