package com.yijian.bbs.dao.user;

import com.yijian.bbs.model.User;
//用戶操作類
public interface UserDAO {
	// 查询用户
	public User getUserByLogin(User user);

}
