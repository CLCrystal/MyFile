package com.yijian.bbs.service;

import java.util.List;

import com.yijian.bbs.model.Text;

public interface TextService {
	// 分页查询所有帖子
	public List<Text> queryAllTextpage(int page, int pageSize);

	// 查询一共多少条信息？
	public int getCountText();

	// 分页查询 所有栏目所有信息？
	public List<Text> queryAllTextpageYuLe(int page, int pageSize, int Id);

	// 查询一共多少条信息？
	public int getCountTextYuLe(int Id);
}
