package com.yijian.bbs.service;

import com.yijian.bbs.model.User;

public interface UserService {
	public User login(User user);
}
