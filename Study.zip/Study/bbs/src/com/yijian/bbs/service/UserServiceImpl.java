package com.yijian.bbs.service;

import com.yijian.bbs.dao.user.UserDAO;
import com.yijian.bbs.dao.user.UserDAOImpl;
import com.yijian.bbs.model.User;

public class UserServiceImpl implements UserService{

	public User login(User user) {
		UserDAO dao=new UserDAOImpl();
		return dao.getUserByLogin(user);
	}

}
