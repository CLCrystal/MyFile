package com.yijian.bbs.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;
//数据库操作类
public class DBUtils {
	private static final String className="com.mysql.jdbc.Driver";
	private static final String user="root";
	private static final String password="tiger";
	private static final String url="jdbc:mysql://localhost:3306/db01";
	

	static{
		try {
			Class.forName(className);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
   //获取连接对象
	public static Connection getConnection(){
		Connection conn=null;
		try {
        conn=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

	//connection
	public static void closeConnection(Connection conn){
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	//Statement
	public static void closePreparedStatement(PreparedStatement pstmt){
		if(pstmt!=null){
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
   //ResultSet
	public static void closeResultSet(ResultSet rs){
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
    //关闭资源
	public static void closeAll(Connection conn,PreparedStatement pstmt,ResultSet rs){
		closeResultSet(rs);
		closePreparedStatement(pstmt);
		closeConnection(conn);
		
	}
	@Test //测试获取连接对象
	public void test(){
		System.out.println(getConnection());
		
	}
	
	
}
