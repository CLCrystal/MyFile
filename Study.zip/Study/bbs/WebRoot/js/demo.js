function myFunction() {
	x = document.getElementById("demo"); // 找到元素
	x.innerHTML = "Hello JavaScript!"; // 改变内容
}

function changeImage() {
	element = document.getElementById('myimage'); // 找到元素
	if (element.src.match("bulbon")) { // 匹配内容字符串
		element.src = "images/pic_bulboff.gif"; // 修改属性
	} else {
		element.src = "images/pic_bulbon.gif";
	}
}

function changeCss() {
	x = document.getElementById("cssdemo"); // 找到元素
	x.style.color = "#ff0000"; // 改变样式
}