var i = 4;
var intervalid;
intervalid = setInterval("fun()", 1000);
function fun() {
	if (i == 0) {
		window.location.href = "login.jsp";
		clearInterval(intervalid);
	}
	document.getElementById("time").innerHTML = i;
	i--;
}

