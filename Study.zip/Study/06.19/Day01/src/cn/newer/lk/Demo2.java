package cn.newer.lk;

import java.util.Scanner;

public class Demo2 {
	// 判断某一个整数是否为prime（素数，质数）。2, 3, 5, 7,11,13 17, 19
	// 素数：如果只能被1和自己整除的自然数，不能被2..m-1之间整除
	// 整除就是取模等于0
	 public static void main(String[] args) {
		 
		 //实例化一个扫描器
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("请输入一个数:");
		 int m=sc.nextInt(),i;
		 
		 //判断是否能被整除  能则不是素数
		 for (i = 2; i <=m-1; i++) {
			 if(m%i==0){
				 break; 
			 }
		}
		 if(m==i){
			 System.out.println(m+"是素数");
		 }else{
			 System.out.println(m+"不是素数"); 
		 }
		
	}

}
