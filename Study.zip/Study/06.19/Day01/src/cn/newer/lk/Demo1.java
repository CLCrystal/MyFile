package cn.newer.lk;
/**
 * 语法的复习
 * @ProjectName:   Day01 
 * @ClassName:     Demo1 
 * @Description:   TODO
 * @author:        HP
 * @date:          2017-6-19 下午1:49:36
 * @version 1.0.0
 */
public class Demo1 {
	
	 public static void main(String[] args) {
		
		//变量的声明 
		int m=2;
		//break 的使用
		switch (m) {
		case 2:
			System.out.println(2);
			break;
		case 4:
			System.out.println(4);
			break;
		case 6:
			System.out.println(6);
			break;
		default:
			System.out.println("others");
			break;
		}
	}
	

}
