package cn.newer.demo1;

import java.util.Random;

/**
 * 随机数
 * 
 * @author lenovo
 * 
 */
public class Demo4 {
	public static void main(String[] args) {
		Random random = new Random(); // 银行里的那个排队机

		// random.nextInt(10)//[0, 9)
		// 100-200的随机数
		for (int i = 1; i < 100; i++) {
			int m = 100 + random.nextInt(101);
			System.out.println(m);
		}
		// 准备一副牌
		int a[] = new int[52];
		for (int i = 0; i < a.length; i++) {
			a[i] = i + 1;
		}
		// 打乱这副牌
		/**
		 * 洗牌策略：将最后一张牌与前面的某张牌进行交换
		 */
		// 1 2 3 4 5 6 7 52 9 10 11 12 13 14 ...49 50 8
		// 1 2 3 4 5 6 50 52 9 10 11 12 13 14 ... 49 7 8
		// 1 2 3 4 5 6 50 52 9 10 11 12 13 14 ... 49 48 7 8
		for (int i = a.length - 1; i > 0; i--) {
			int r = random.nextInt(i); // 得到 i 前面的某张随机牌
			int temp = a[i]; // a[i]是最后一张牌
			a[i] = a[r];
			a[r] = temp;
		}
		// 输出这副牌
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
	}
}