package cn.newer.demo1;

import java.util.Random;

//洗牌
public class Demo5 {
	public static void main(String[] args) {

		System.out.println(1000000 / 1000001); // 整除：xx倍
		System.out.println(1000000.0f / 1000001.0f);
		// 一张牌
		Card card1 = new Card(1, 10);
		System.out.println(card1);

		// 一副牌
		Card cards[] = new Card[52];
		for (int i = 0; i < cards.length; i++) {
			cards[i] = new Card(i / 13 + 1, i % 13 + 1);
		}

		// 洗牌
		Random random = new Random();
		for (int i = cards.length - 1; i > 0; i--) {
			int r = random.nextInt(i);
			Card temp = cards[r];
			cards[r] = cards[i];
			cards[i] = temp;
		}

		for (int i = 0; i < cards.length; i++) {
			System.out.println(cards[i]);
		}

	}
}
