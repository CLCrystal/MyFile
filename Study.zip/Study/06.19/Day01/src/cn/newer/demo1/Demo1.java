package cn.newer.demo1;
/**
 * 语法的复习
 * @author lenovo
 * break只能在循环和switch中使用
 * break用在循环的作用是跳出本循环
 * break用在switch的作业是离开switch语句，否则匹配成功以后会不加判断地执行后面的所有的语句
 *
 */
public class Demo1 {
	public static void main(String[] args) {
		int m = 2;
		switch (m ){
			case 2: System.out.println(2);
						break;
			case 4: System.out.println(4);
						break;
			case 6: System.out.println(6);
						break;
			default:
						System.out.println("other");
		
		}
	}
}
