package cn.newer.demo1;

/*1-9九个数字组成三个百位数a、b和c
 * 满足c = 3 * a;  b = 2 *a 
 * 请找出所有符合条件的a、b和c
 * a=192  b = 384   c = 576
 * 
 */
public class Demo3 {
	public static void main(String[] args) {
		for (int a = 100; a <= 999 / 3; a++) {
			if (check(a)) {
				System.out.println(a + " " + 2 * a + ", " + 3 * a);
			}
		}
	}

	/**
	 * 用来检查某个指定的a是否符合条件
	 * 
	 * @param a
	 *            ：指定的a
	 * @return true: 符合条件
	 * @return false: 不符合条件
	 */
	private static boolean check(int a) {
		int box[] = new int[10]; // 准备10个空盒子

		for (int i = 1; i <= 3; i++) {
			box[i * a / 100] = 1;
			box[i * a / 10 % 10] = 1;
			box[i * a % 10] = 1;
		}
		for (int i = 1; i < box.length; i++) {
			if (box[i] == 0) {
				return false;
			}
		}
		return true;
	}

}