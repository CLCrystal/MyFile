package cn.newer.demo1;

//问题：为什么要定义为int，而不是String？
public class Card {
	private int face; // 花色
	private int value; // 点数
	
	/*得到扑克牌对象的中文描述信息
	 * 花色 1：黑桃  2：红桃  3：梅花  4：方块
	 * 点数 1：A  2-10保持不变  11：J   12:Q   13:K 
	 * face = 2   value = 6  红桃6
	 * face = 1   value = 11  黑桃A 
	 */
	public String toString() {
		String cnFace = null, cnValue = null;
		switch(face){
			case 1: cnFace = "黑桃"; break;
			case 2: cnFace = "红桃"; break;
			case 3: cnFace = "梅花"; break;
			case 4: cnFace = "方块"; break;
			default:
				cnFace ="大小王";
		}
		switch(value){
			case 1:  cnValue = "A"; break;
			case 11:  cnValue = "J"; break;
			case 12:  cnValue = "Q"; break;
			case 13:  cnValue = "K"; break;
			default:
				 cnValue = ""+value;
		}
		return cnFace + cnValue;
	}

	public Card() {
	}

	public Card(int face, int value) {
		this.face = face;
		this.value = value;
	}

	public void setFace(int face) {
		this.face = face;
	}

	public int getFace() {
		return face;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
