/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mydbs

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-09-15 18:45:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `realname` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `age` int(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `tel` varchar(50) NOT NULL,
  `addtime` date NOT NULL,
  `status` int(1) NOT NULL,
  `job_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', '奉', '123456', '奉小军', '男', '10', '湖南永州', '12312431241', '2017-08-25', '1', null);
INSERT INTO `admin` VALUES ('2', 'feng', '1234', '奉大神', '男', '20', '湖南永州', '124314123', '2017-08-26', '0', '1');
INSERT INTO `admin` VALUES ('3', '韩天烦', '1233', '韩天饭', '女', '19', '湖南永州', '1231241412', '2017-08-27', '0', '3');
INSERT INTO `admin` VALUES ('5', '谢扁', '21414321', '谢媛', '女', '18', '湖南邵阳', '214123124', '2017-08-27', '0', '3');
INSERT INTO `admin` VALUES ('6', '小明', '214241', '小小', '男', '19', '湖南郴州', '1761263216312', '2017-08-27', '0', '2');
INSERT INTO `admin` VALUES ('7', '橡皮筋', '111111', '项晶', '女', '18', '湖南益阳', '12314124', '2017-08-28', '0', '5');
INSERT INTO `admin` VALUES ('8', 'hexuan', '111111', '何宣婷', '男', '19', '湖南衡阳', '231241', '2017-02-28', '0', '7');
INSERT INTO `admin` VALUES ('9', '奉神', '1111', '奉神', '男', '19', '湖南', '123414124', '2017-08-28', '0', '1');
INSERT INTO `admin` VALUES ('10', 'hh', '1312312', 'hh', '女', '18', '湖南', '12312', '2017-08-28', '0', '4');
INSERT INTO `admin` VALUES ('11', 'ha', '1243124', 'haha', '男', '19', '湖南', '214141', '2017-08-28', '0', '2');
INSERT INTO `admin` VALUES ('13', 'luoer', '12345', '罗儿', '男', null, null, '110', '2017-08-30', '0', '2');
INSERT INTO `admin` VALUES ('14', '3701', '123456', '奉大神', '男', null, null, '124314123', '2017-08-30', '0', '1');
INSERT INTO `admin` VALUES ('15', '10086', '11111', '张三', '男', null, null, '10010', '2017-08-30', '0', '6');
INSERT INTO `admin` VALUES ('16', 'hello', 'hello', '张三丰', '男', null, null, '112312321321', '2017-09-01', '0', '7');
INSERT INTO `admin` VALUES ('17', 'his', '12345678', '教授', '男', null, null, '1132132132', '2017-09-01', '0', '7');
INSERT INTO `admin` VALUES ('18', '1233', '100000', '鑫哥', '男', null, null, '124124321', '2017-09-02', '0', '3');

-- ----------------------------
-- Table structure for `business`
-- ----------------------------
DROP TABLE IF EXISTS `business`;
CREATE TABLE `business` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `emp_id` int(10) NOT NULL,
  `date` int(10) NOT NULL,
  `subsidy` float(10,0) NOT NULL,
  `detail` varchar(50) NOT NULL,
  `count` float(50,0) NOT NULL,
  `year` int(10) NOT NULL,
  `month` int(10) NOT NULL,
  PRIMARY KEY (`id`,`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of business
-- ----------------------------
INSERT INTO `business` VALUES ('1', '2', '2', '100', '666', '200', '2017', '8');
INSERT INTO `business` VALUES ('2', '5', '4', '100', '好样的！', '400', '2017', '1');
INSERT INTO `business` VALUES ('3', '6', '10', '10', '出去搞事情', '100', '2017', '9');

-- ----------------------------
-- Table structure for `department`
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(20) NOT NULL,
  `detail` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`dept_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('1', '技术部', '搞技术的哦');
INSERT INTO `department` VALUES ('2', '美化部', '搞美化的哦！');
INSERT INTO `department` VALUES ('3', '管理部', '搞管理');
INSERT INTO `department` VALUES ('4', '业务部', '搞业务的');
INSERT INTO `department` VALUES ('5', '人力资源部', '搞人力资源的');

-- ----------------------------
-- Table structure for `job`
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `job_name` varchar(20) NOT NULL,
  `deail` float(10,0) NOT NULL,
  `dept_id` int(3) NOT NULL,
  PRIMARY KEY (`id`,`job_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of job
-- ----------------------------
INSERT INTO `job` VALUES ('1', '主管', '20900', '4');
INSERT INTO `job` VALUES ('2', '写代码', '20000', '1');
INSERT INTO `job` VALUES ('3', '美工师', '15001', '2');
INSERT INTO `job` VALUES ('4', '测试员', '10000', '1');
INSERT INTO `job` VALUES ('5', '普通员工', '8000', '4');
INSERT INTO `job` VALUES ('6', '促销', '9000', '5');
INSERT INTO `job` VALUES ('7', '销售', '8000', '5');
INSERT INTO `job` VALUES ('8', '咨询部', '9000', '4');

-- ----------------------------
-- Table structure for `salary`
-- ----------------------------
DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `emp_id` int(50) NOT NULL,
  `year` int(20) NOT NULL,
  `month` int(20) NOT NULL,
  `date` int(50) NOT NULL,
  `business` int(1) NOT NULL,
  `work` int(6) NOT NULL,
  `meal_fate` float(10,0) NOT NULL,
  `base_wage` float(20,0) NOT NULL,
  `medical_insurance` float(20,0) NOT NULL,
  `lose_insurance` float(20,0) NOT NULL,
  `endowment_insurance` float(20,0) NOT NULL,
  `yeji` float(20,0) DEFAULT NULL,
  `qita` float(20,0) DEFAULT NULL,
  `gzzj` float(20,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of salary
-- ----------------------------
INSERT INTO `salary` VALUES ('1', '2', '2017', '8', '30', '2', '28', '10', '20501', '410', '103', '1435', '200', '100', '18853');
INSERT INTO `salary` VALUES ('3', '5', '2017', '9', '30', '0', '28', '10', '15001', '300', '75', '1050', '200', '200', '13876');
INSERT INTO `salary` VALUES ('4', '6', '2017', '9', '30', '0', '28', '10', '20000', '400', '100', '1400', '200', '200', '18400');
