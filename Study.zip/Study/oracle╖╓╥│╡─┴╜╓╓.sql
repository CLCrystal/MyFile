

select * from emp

 --��������
 with tb(id,name,age,rn)
 as (
  select e.*,row_number() over(order by id)
  from emp e 
 )
 select * from tb
 
 --α��
 with tb(id,name,age,rn)
 as(
   select e.*,rownum rn 
   from (select e1.* from emp e1 order by e1.id) e
 )
 select * from tb


